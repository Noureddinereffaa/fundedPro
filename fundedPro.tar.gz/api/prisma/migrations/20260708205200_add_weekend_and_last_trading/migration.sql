-- AlterTable
ALTER TABLE "accounts" ADD COLUMN "last_trading_day" TIMESTAMP(3);
ALTER TABLE "accounts" ADD COLUMN "weekend_trading" BOOLEAN NOT NULL DEFAULT false;
